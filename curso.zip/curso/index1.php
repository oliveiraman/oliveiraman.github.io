<?php

include 'conexao.php';
include 'script/password.php';

$usuario = $_POST['usuario'];
$senhausuario = $_POST['senhausuario'];


$sql = "select mail_usuario, senha_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);

$total = mysqli_num_rows($buscar); //se não retornar linha ele não está cadastrado

do  {
	
$senha = $array['senha_usuario'];


$senhadecodificada = sha1($senhausuario);



		if ($total > 0)  {
			
			if ($senhadecodificada ==$senha) {
				//inicia a sessão do usuário, atribuindo o e-mail
				session_start();
				$_SESSION['usuario'] =$usuario;

				header('Location: menu.php');
			} else {

				header('Location: erro1.php');				
			}


		} else { 

			header('Location: erro.php');

		}
} while ($array = mysqli_fetch_array($buscar));

?>