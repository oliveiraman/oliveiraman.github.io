<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<!-- AUTO AJUSTAR TELA DE LOGIN EM DISPOSITIVOS MÓVEIS --> 
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
	<!-- AUTO AJUSTAR TELA DE LOGIN EM DISPOSITIVOS MÓVEIS --> 
	<title>Tela de Login</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <style type="text/css">
    	#tamanho{
    		width: 350px;

    		/*SITE COLOCAR SOMBRA CONTAINERhttps://www.cssmatic.com/box-shadow*/

			-webkit-box-shadow: 10px 10px 28px -8px rgba(171,166,171,1);
			-moz-box-shadow: 10px 10px 28px -8px rgba(171,166,171,1);
			box-shadow: 10px 10px 28px -8px rgba(171,166,171,1);
    	}
    </style>
</head>
<body>

<div class="container" id="tamanho" style="margin-top: 100px; border-radius: 15px; border: 2px solid #f3f3f3" >
	<div style="padding: 10px">
	<center>
<img src="imagem/cadeado.png" width="125px" height="125px">
	</center>

<form action="index1.php" method="post">
	<div class="form-group">
		<label>Usuário</label>
		<input type="text" name="usuario" class="form-control" placeholder="Usuário" autocomplete="off" required>
	</div>
		<div class="form-group">
		<label>Senha do Usuário</label>
		<input type="password" name="senhausuario" class="form-control" placeholder="Digite sua senha" autocomplete="off" required>
		
	</div>

	<div style="text-align: right;">
	<button type="submit"class="btn btn-sm btn-success">Entrar</button>
</div>
		

</form>






</div>
</div>


<div style="margin-top: 10px">
<center>
	<small>Você não possui Cadastro? Clique<a href="cadastro_usuario_externo.php"> aqui</a></small>
</center>
</div>

<script type="text/javascript" src=js/bootstap.js></script>
</body>
</html>