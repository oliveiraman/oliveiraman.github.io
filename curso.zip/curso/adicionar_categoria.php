<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
	<title>Adicionar Categoria</title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<style type="text/css">
		
		#tamanhoContainer {
			width: 500px;
		}

		#botao {
			background-color: #FF1168; /*cor de fundo*/
			color: #ffffff; /*cor da letra*/

		}
	</style>
</head>
<body>

<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>	


<div class="container" id="tamanhoContainer" style="margin-top: 40px">

<div style="text-align: right">
	<a href="menu.php" role="button" class="btn btn-sm btn-primary">Voltar</a>
</div>

	<h4>Cadastro de Categoria</h4>

	<form action="_inserir_categoria.php" method="post" style="margin-top: 20px">

	<div class="form-group">
	    <label>Categoria</label>
	    <input type="text" class="form-control" name="categoria" placeholder="Digite o nome da categoria" autocomplete="off" required>
	    </small>
	 </div>


  	 <div style="text-align: right;">
  	  	<button type="submit" id="botao" class="btn btn-sm">Cadastrar</button>
	 </div>


 </form>



</div>









<script type="text/javascript" src=js/bootstap.js></script>
</body>
</html>