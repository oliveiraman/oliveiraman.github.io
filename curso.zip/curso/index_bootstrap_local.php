<!DOCTYPE html>
<html>
<head>
	<title>Meu Primeiro Script</title>
	<link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>



<button type="button" class="btn btn-primary">Primary</button>
<button type="button" class="btn btn-secondary">Secondary</button>
<button type="button" class="btn btn-success">Success</button>
<button type="button" class="btn btn-danger">Danger</button>
<button type="button" class="btn btn-warning">Warning</button>
<button type="button" class="btn btn-info">Info</button>
<button type="button" class="btn btn-light">Light</button>
<button type="button" class="btn btn-dark">Dark</button>

<button type="button" class="btn btn-link">Link</button>





<script type="text/javascript" src=js/bootstap.js></script>
</body>
</html>