<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

<?php
include 'conexao.php';

$id = $_POST['id'];
$nomeproduto = $_POST['nomeproduto'];
$categoria = $_POST['categoria'];
$quantidade = $_POST['quantidade'];
$fornecedor = $_POST['fornecedor'];


$sql="UPDATE estoque
SET
`nomeproduto` = '$nomeproduto',
`quantidade` = $quantidade,
`categoria` = '$categoria',
`fornecedor` = '$fornecedor'
WHERE id_estoque = $id;
";


$atualizar = mysqli_query($conexao,$sql);


?>
<link rel="stylesheet" href="css/bootstrap.css">
<div class="container" style="width: 400px">
	<center>
			<h3>Atualizado com sucesso</h3>
				<div style="margin-top: 10px">
					<a href="listar_produtos.php" class="btn btn-sm btn-warning" style="color: #fff">Voltar</a>
				</div>
	</center>

</div>
