<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

<?php

include 'conexao.php';
$id = $_GET['id'];
$nivel = $_GET['nivel'];

if ($nivel ==1) {
	
	$update = "update usuarios set status='Ativo', nivel_usuario=1 where id_usuario=$id";
	$atualizacao = mysqli_query($conexao,$update);
	echo "Administrador Aprovado";
}

if ($nivel ==2) {
	
	$update = "update usuarios set status='Ativo', nivel_usuario=2 where id_usuario=$id";
	$atualizacao = mysqli_query($conexao,$update);
	echo "Funcionário Aprovado";
}

if ($nivel ==3) {
	
	$update = "update usuarios set status='Ativo', nivel_usuario=3 where id_usuario=$id";
	$atualizacao = mysqli_query($conexao,$update);
	echo "Conferente Aprovado";
}

header ("Location: aprovar_usuario.php"); //redireciona novamente para a página de aprovação


?>