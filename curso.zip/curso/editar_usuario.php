<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Listagem de Usuários</title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<script src="https://kit.fontawesome.com/c40a319c80.js" crossorigin="anonymous"></script>
</head>
<body>

<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

<div class="container" id="tamanhoContainer" style="margin-top: 40px">
  <div style="text-align: right">

<a href="menu.php" role="button" class="btn btn-sm btn-primary">Voltar</a>

  </div>
<h3>Lista de Usuários</h3>
<br>
<table class="table">
  <thead>
    <tr>
      <th scope="col">ID Usuário</th>
      <th scope="col">Nome Usuário</th>
      <th scope="col">E-mail Usuário</th>
      <th scope="col">Status</th>
      <th scope="col">Nível Usuário</th>
      <th scope="col">Ação</th>
    </tr>
  </thead>
 
   
    	<?php 
    		include 'conexao.php';
    		$sql="select * from usuarios";
    		$busca = mysqli_query($conexao,$sql);

    		while ($array = mysqli_fetch_array($busca)) {
    			
    			$id_usuario = $array['id_usuario'];
    			$nome_usuario = $array['nome_usuario'];
    			$mail_usuario = $array['mail_usuario'];
    			$status = $array['status'];
    			$nivel_usuario = $array['nivel_usuario'];
    			
    		
    		?>
     <tr>

      <td><?php echo $id_usuario ?></td>
      <td><?php echo $nome_usuario ?></td>
      <td><?php echo $mail_usuario ?></td>
      <td><?php echo $status ?></td>
      <td><?php  
      if ($nivel_usuario ==1) {
      $descricao_usuario = 'Administrador';
      };
      if ($nivel_usuario ==2) {
      $descricao_usuario = 'Funcionário';
      };
      if ($nivel_usuario ==3) {
      $descricao_usuario = 'Conferente';
      };
      echo $descricao_usuario;

       ?>
        



      </td>
      <td><a class="btn btn-warning btn-sm" style="color: #fff" href="_editar_usuario.php?id=<?php echo $id_usuario ?>" role="button"><i class="far fa-edit"></i>&nbsp;Editar</a>

      <a class="btn btn-danger btn-sm" style="color: #fff" href="_deletar_usuario2.php?id=<?php echo $id_usuario ?>" role="button"><i class="far fa-trash-alt"></i>&nbsp;Excluir</a></td>
 


  <?php } ?>

    </tr>
    
 
</table>





</div>

<script type="text/javascript" src=js/bootstap.js></script>
</body>
</html>