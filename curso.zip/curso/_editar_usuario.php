<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

<?php
include 'conexao.php';


 $id = $_GET['id'];



?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Edição de Usuários</title>
	<link rel="stylesheet" href="css/bootstrap.css">

	<style type="text/css">
		
		#tamanhoContainer {
			width: 500px;
		}

		#botao {
			background-color: #FF1168; /*cor de fundo*/
			color: #ffffff; /*cor da letra*/

		}
	</style>

</head>
<body>

<div class="container" id="tamanhoContainer" style="margin-top: 40px">
	<h4>Edição de Usuário</h4>
	<form action="_atualizar_usuario.php" method="post" style="margin-top: 20px">
		<?php
		$sql = "select * from usuarios where id_usuario= $id";
		$buscar = mysqli_query($conexao,$sql);
		while ($array = mysqli_fetch_array($buscar)) {	
		
    			
    			$id_usuario = $array['id_usuario'];
    			$nome_usuario = $array['nome_usuario'];
    			$mail_usuario = $array['mail_usuario'];
    			$nivel_usuario = $array['nivel_usuario'];
    			$status = $array['status'];			

		
		?>




	<div class="form-group">
	    <label>ID usuário</label>
	    <input type="number" class="form-control" name="id_usuario" value="<?php echo $id_usuario ?>" disabled>
	    <input type="number" class="form-control" name="id" value="<?php echo $id_usuario ?>" style="display: none">
	    </small>
	  </div>
	  <div class="form-group">
	    <label>Nome do Usuário</label>
	    <input type="text" class="form-control" name="nome_usuario"  value="<?php echo $nome_usuario ?>">
	    </small>
	  </div>
	   <div class="form-group">
	    <label>E-mail do Usuário</label>
	    <input type="text" class="form-control" name="mail_usuario"  value="<?php echo $mail_usuario ?>">
	    </small>
	  </div>
	  
	  	<div class="form-group">
	  		<label>Nível de Usuário</label>
    		<select class="form-control" name="nivel_usuario" value="
    		<?php  
      			if ($nivel_usuario ==1) {
      				$descricao_usuario = 'Administrador';
      									};
      			if ($nivel_usuario ==2) {
      				$descricao_usuario = 'Funcionário';
      									};
      			if ($nivel_usuario ==3) {
      				$descricao_usuario = 'Conferente';
      									};
      			echo $descricao_usuario;?>">>
      			<option><?php echo $descricao_usuario?></option>
      			<option></option>
      			<option>Administrador</option>
      			<option>Funcionário</option>
      			<option>Conferente</option>
      			      			
    		</select>
  		</div> 

 	   <div class="form-group">
	    <label>Status do Usuário</label>
	    <input type="text" class="form-control" name="status"  value="<?php echo $status ?>" disabled>
	    </small>
	  </div>
  	  	<div style="text-align: right;">
  			<button type="submit" id="botao" class="btn btn-sm">Atualizar</button>
	   	</div>
	   	  <?php } ?>
	 </form>
</div>


<script type="text/javascript" src=js/bootstap.js></script>
</body>
</html>