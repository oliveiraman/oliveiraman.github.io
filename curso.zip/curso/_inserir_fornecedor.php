<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

<?php

include 'conexao.php';

$fornecedor = $_POST['fornecedor'];



$sql = "INSERT INTO fornecedor (fornecedor)	VALUES	('$fornecedor')";


$inserir=mysqli_query($conexao,$sql);

?>

<link rel="stylesheet" href="css/bootstrap.css">

<div class="container" style="width: 500px; margin-top: 20px">
		<center>
			<h4>Fornecedor Adicionada com sucesso!</h4>
				<div style="padding-top: 20px">
					<center>
						<a href="adicionar_categoria.php" role="button" class="btn btn-sm btn-primary">Cadastrar novo fornecedor</a>
					</center>
				</div>
		</center>
</div>