<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

<?php
include 'conexao.php';


 $id = $_GET['id'];



?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Formulário de Edição</title>
	<link rel="stylesheet" href="css/bootstrap.css">

	<style type="text/css">
		
		#tamanhoContainer {
			width: 500px;
		}

		#botao {
			background-color: #FF1168; /*cor de fundo*/
			color: #ffffff; /*cor da letra*/

		}
	</style>

</head>
<body>

<div class="container" id="tamanhoContainer" style="margin-top: 40px">
	<h4>Formulário de Edição</h4>
	<form action="_atualizar_fornecedor.php" method="post" style="margin-top: 20px">
		<?php
		$sql = "select * from fornecedor where id_fornecedor= $id";
		$buscar = mysqli_query($conexao,$sql);
		while ($array = mysqli_fetch_array($buscar)) {	
		
    			
    			$id_fornecedor = $array['id_fornecedor'];
    			$fornecedor = $array['fornecedor'];
		

		
		?>




	  <div class="form-group">
	    <label>Nome Fornecedor</label>
	    <input type="text" class="form-control" name="fornecedor"  value="<?php echo $fornecedor ?>">
	    <input type="text" class="form-control" name="id"  value="<?php echo $id_fornecedor ?>" style="display: none">
	    </small>
	  </div>
	  
  	  	<div style="text-align: right;">
  			<button type="submit" id="botao" class="btn btn-sm">Atualizar</button>
	   	</div>
	   	  <?php } ?>
	 </form>
</div>


<script type="text/javascript" src=js/bootstap.js></script>
</body>
</html>