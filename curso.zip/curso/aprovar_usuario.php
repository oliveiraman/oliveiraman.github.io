<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aprovar usuário</title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<script src="https://kit.fontawesome.com/c40a319c80.js" crossorigin="anonymous"></script>
</head>
<body>

<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

<div class="container" id="tamanhoContainer" style="margin-top: 40px; ">
  <div style="text-align: right">

<a href="menu.php" role="button" class="btn btn-sm btn-primary">Voltar</a>

  </div>
<h3>Lista de Usuários</h3>
<br>

<table class="table">
  <thead>
    <tr>
      <th scope="col">Nome</th>	
      <th scope="col">E-mail</th> 
      <th scope="col">Nível</th> 
      <th scope="col">Ação</th>
    </tr>
  </thead>
   	<?php 
    		include 'conexao.php';
    		$sql="select * from usuarios where status = 'Inativo'";
    		$busca = mysqli_query($conexao,$sql);

    			while ($array = mysqli_fetch_array($busca)) {
    			
    			$id_usuario = $array['id_usuario'];
    			$nome_usuario = $array['nome_usuario'];
          $mail_usuario = $array['mail_usuario'];
          $nivel_usuario = $array['nivel_usuario'];


   	?>
     <tr>

      <td><?php echo $nome_usuario ?></td>
      <td><?php echo $mail_usuario ?></td>
      <td><?php echo $nivel_usuario ?></td>


       <td><a class="btn btn-success btn-sm" style="color: #fff" href="_aprovar_usuario.php?id=<?php echo $id_usuario ?>&nivel=1" role="button"><i class="far fa-smile-beam"></i>&nbsp;Administrador</a>
        <a class="btn btn-warning btn-sm" style="color: #fff" href="_aprovar_usuario.php?id=<?php echo $id_usuario ?>&nivel=2" role="button"><i class="far fa-smile-beam"></i>&nbsp;Funcionário</a>
        <a class="btn btn-dark btn-sm" style="color: #fff" href="_aprovar_usuario.php?id=<?php echo $id_usuario ?>&nivel=3" role="button"><i class="far fa-smile-beam"></i>&nbsp;Conferente</a>

      <a class="btn btn-danger btn-sm" style="color: #fff" href="_deletar_usuario.php?id=<?php echo $id_usuario ?>" role="button"><i class="far fa-trash-alt"></i>&nbsp;Excluir</a></td>
 


  <?php } ?>

    </tr>
    
 
</table>





</div>

















<script type="text/javascript" src=js/bootstap.js></script>

</body>
</html>