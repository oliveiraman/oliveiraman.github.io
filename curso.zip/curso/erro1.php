<link rel="stylesheet" href="css/bootstrap.css">

<div class="container" style="width: 500px; margin-top: 20px">
		<center>
			<h4>Erro</h4>
				<div style="padding-top: 20px">
					<center>
						<a href="index.php" role="button" class="btn btn-sm btn-primary">Senha Incorreta!</a>
					</center>
				</div>
		</center>
</div>