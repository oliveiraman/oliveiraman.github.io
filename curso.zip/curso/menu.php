<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Menu</title>
	<link rel="stylesheet" href="css/bootstrap.css">

</head>
<body>


<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

  <div style="text-align: right; margin-right: 100px; margin-top: 10px">

  
<a href="fechar.php" role="button" class="btn btn-sm btn-primary">Sair</a>

  </div>

<div class="container" style="margin-top: 100px">

<h4 style="text-align: center; margin: 20px">CONTROLE DE PRODUTOS</h4>

<div class="row">

<?php
//esconde menu para outros níveis

if (($nivel == 1)||($nivel ==2)) {

?>

  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Adicionar Produto</h5>
        <p class="card-text">Opção para adicionar produtos em nosso estoque.</p>
        <a href="adicionar_produto.php" class="btn btn-primary">Cadastrar Produto</a>
      </div>
    </div>
  </div>

<?php } ?>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Lista de Produtos</h5>
        <p class="card-text">Visualizar, editar e excluir os produtos.</p>
        <a href="listar_produtos.php" class="btn btn-primary">Produtos</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6" style="margin-top: 20px">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Adicionar Categoria</h5>
        <p class="card-text">Opção para adicionar categorias..</p>
        <a href="adicionar_categoria.php" class="btn btn-primary">Cadastrar Categoria</a>
        <a href="listar_categoria.php" class="btn btn-primary">Listar Categoria</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6" style="margin-top: 20px">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Adicionar Fornecedor</h5>
        <p class="card-text">Opção para adicionar fornecedores..</p>
        <a href="adicionar_fornecedor.php" class="btn btn-primary">Cadastrar Fornecedor</a>
        <a href="listar_fornecedor.php" class="btn btn-primary">Listar fornecedor</a>
      </div>
    </div>
  </div>

<?php
//esconde menu para outros níveis

if ($nivel == 1) { 
  ?>

      <div class="col-sm-6" style="margin-top: 20px">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Controle de Usuários</h5>
        <p class="card-text">Cadastrar, aprovar e editar usuários</p>
        <a href="cadastro_usuario.php" class="btn btn-primary">Cadastrar Usuários</a>
        <a href="aprovar_usuario.php" class="btn btn-primary">Aprovar Usuários</a>
        <a href="editar_usuario.php" class="btn btn-primary">Editar Usuários</a>
      </div>
    </div>
  </div>

  <?php } ?>

</div>
</div>





<script type="text/javascript" src=js/bootstap.js></script>
</body>
</html>