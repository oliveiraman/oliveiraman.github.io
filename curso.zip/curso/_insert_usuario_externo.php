<?php
include 'conexao.php';
include 'script/password.php';



$nomeusuario = $_POST['nomeusuario'];
$mail = $_POST['mailusuario'];
$senha = $_POST['senhausuario'];
//$nivel = $_POST['nivelusuario'];
$status= 'Inativo';

$sql = "INSERT INTO usuarios (nome_usuario,mail_usuario,senha_usuario, status) values ('$nomeusuario','$mail',sha1('$senha'), '$status')";

$inserir = mysqli_query($conexao,$sql);



?>
<link rel="stylesheet" href="css/bootstrap.css">

<div class="container" style="width: 500px; margin-top: 20px">
		<center>
			<h4> Usuário adicionado com sucesso, esperando aprovação</h4>
				<div style="padding-top: 20px">
					<center>
						<a href="cadastro_usuario.php" role="button" class="btn btn-sm btn-primary">Voltar</a>
					</center>
				</div>
		</center>
</div>