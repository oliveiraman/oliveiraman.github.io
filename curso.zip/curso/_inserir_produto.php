<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

<?php

include 'conexao.php';

$nroproduto = $_POST['nroproduto']; // recebe valor do atributo
$nomeproduto = $_POST['nomeproduto'];
$quantidade = $_POST['quantidade'];
$categoria = $_POST['categoria'];
$fornecedor = $_POST['fornecedor'];





$sql = "INSERT INTO estoque
	(
	`nroproduto`,
	`nomeproduto`,
	`quantidade`,
	`categoria`,
	`fornecedor`
	)

	VALUES
	(
	
	$nroproduto,
	'$nomeproduto',
	$quantidade,
	'$categoria',
	'$fornecedor')";

	$inserir=mysqli_query($conexao,$sql);

?>
<link rel="stylesheet" href="css/bootstrap.css">

<div class="container" style="width: 500px; margin-top: 20px">
		<center>
			<h4> Produto Adicionado com sucesso!</h4>
				<div style="padding-top: 20px">
					<center>
						<a href="adicionar_produto.php" role="button" class="btn btn-sm btn-primary">Cadastrar novo Ítem</a>
					</center>
				</div>
		</center>
</div>