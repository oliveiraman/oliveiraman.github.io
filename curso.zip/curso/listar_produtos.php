<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Listagem de Produtos</title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<script src="https://kit.fontawesome.com/c40a319c80.js" crossorigin="anonymous"></script>
</head>
<body>

<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

<div class="container" id="tamanhoContainer" style="margin-top: 40px">
  <div style="text-align: right">

<a href="menu.php" role="button" class="btn btn-sm btn-primary">Voltar</a>

  </div>
<h3>Lista de Produtos</h3>
<br>
<table class="table">
  <thead>
    <tr>
      <th scope="col">Nro Produto</th>
      <th scope="col">Nome Produto</th>
      <th scope="col">Categoria</th>
      <th scope="col">Quantidade</th>
      <th scope="col">Fornecedor</th>
      <th scope="col">Ação</th>
    </tr>
  </thead>
 
   
    	<?php 
    		include 'conexao.php';
    		$sql="select * from estoque";
    		$busca = mysqli_query($conexao,$sql);

    		while ($array = mysqli_fetch_array($busca)) {
    			
    			$id_estoque = $array['id_estoque'];
    			$nroproduto = $array['nroproduto'];
    			$nomeproduto = $array['nomeproduto'];
    			$categoria = $array['categoria'];
    			$quantidade = $array['quantidade'];
    			$fornecedor = $array['fornecedor'];
    		
    		?>
     <tr>

      <td><?php echo $nroproduto ?></td>
      <td><?php echo $nomeproduto ?></td>
      <td><?php echo $categoria ?></td>
      <td><?php echo $quantidade ?></td>
      <td><?php echo $fornecedor ?></td>
      <td>

        <?php //esconde botão editar apenas para nivel 3 conferente
          if (($nivel ==1)|| ($nivel ==2)){
        ?>
        <a class="btn btn-warning btn-sm" style="color: #fff" href="editar_produto.php?id=<?php echo $id_estoque ?>" role="button"><i class="far fa-edit"></i>&nbsp;Editar</a>

      <?php }

        if($nivel==1) { //esconde botão excluir para nivel 2 funcionario e nivel 3 conferente
          ?>

      <a class="btn btn-danger btn-sm" style="color: #fff" href="deletar_produto.php?id=<?php echo $id_estoque ?>" role="button"><i class="far fa-trash-alt"></i>&nbsp;Excluir</a></td>
      <?php } ?> 


  <?php } ?>

    </tr>
    
 
</table>





</div>

<script type="text/javascript" src=js/bootstap.js></script>
</body>
</html>