<?php //conferir se o usuário está logado ou não, colar em todas as outras 

session_start();

$usuario=$_SESSION['usuario'];


if (!isset($_SESSION['usuario'])) {
  header ('Location: index.php');
}

//esconde menu para outros níveis
include 'conexao.php';

$sql = "select nivel_usuario from usuarios where mail_usuario='$usuario' and status='Ativo'";
$buscar = mysqli_query($conexao,$sql);
$array = mysqli_fetch_array($buscar);
$nivel = $array['nivel_usuario'];


?>

<?php

include 'conexao.php';
$id=$_GET['id'];

$deletar = "delete from usuarios where id_usuario=$id";
$sql = mysqli_query($conexao, $deletar);


header ("Location: aprovar_usuario.php"); //redireciona novamente para a página de aprovação

?>